<?php
	$h1 = 'Информация обо мне';
	$title = 'Главная страница - страница обо мне';
	$year_now = date("Y");

	include ("main.php");
?>