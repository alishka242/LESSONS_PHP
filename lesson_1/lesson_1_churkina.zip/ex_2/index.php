<?php 
    # Выполнить примеры из методички и разобраться, как это работает.
    echo "Hello, world!";
    echo PHP_EOL;
    $name = 'Alina';
    echo "Hello, $name ";
    define('MY_CONST', 'Red');
    echo MY_CONST;
    $x = 15;
    echo PHP_EOL;
    echo "x = '$x'";

?>